<?php
require_once 'config.php';
checkAuth();

$reviews = loadData('reviews.json');
$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$item = null;

if ($editId) {
    foreach ($reviews as $r) {
        if ($r['id'] === $editId) { $item = $r; break; }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $role = trim($_POST['role'] ?? '');
    $text = trim($_POST['text'] ?? '');
    
    if ($editId && $item) {
        foreach ($reviews as &$r) {
            if ($r['id'] === $editId) {
                $r['name'] = $name;
                $r['role'] = $role;
                $r['text'] = $text;
                break;
            }
        }
    } else {
        $reviews[] = [
            'id' => getNextId($reviews),
            'name' => $name,
            'role' => $role,
            'text' => $text
        ];
    }
    
    saveData('reviews.json', $reviews);
    header('Location: index.php?section=reviews&msg=saved');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $editId ? 'Редактировать' : 'Добавить' ?> отзыв</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f1f5f9; padding: 2rem; }
        .container { max-width: 700px; margin: 0 auto; }
        h1 { font-size: 1.6rem; color: #1B3A6B; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 6px; color: #374151; }
        .form-group input, .form-group textarea { width: 100%; padding: 12px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem; font-family: inherit; }
        .form-group textarea { min-height: 150px; resize: vertical; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #1B3A6B; }
        .btn { display: inline-flex; padding: 14px 28px; border-radius: 10px; text-decoration: none; font-size: 1rem; font-weight: 700; border: none; cursor: pointer; }
        .btn-primary { background: #1B3A6B; color: white; }
        .btn-back { background: #e5e7eb; color: #374151; margin-left: 10px; }
    </style>
</head>
<body>
<div class="container">
    <h1><?= $editId ? '✏️ Редактировать отзыв' : '💬 Добавить отзыв' ?></h1>
    
    <form method="POST">
        <div class="form-group">
            <label>Имя автора *</label>
            <input type="text" name="name" value="<?= htmlspecialchars($item['name'] ?? '') ?>" required placeholder="А.В. Иванов">
        </div>
        
        <div class="form-group">
            <label>Должность / роль</label>
            <input type="text" name="role" value="<?= htmlspecialchars($item['role'] ?? '') ?>" placeholder="полковник полиции, командир ОМОН">
        </div>
        
        <div class="form-group">
            <label>Текст отзыва *</label>
            <textarea name="text" required><?= htmlspecialchars($item['text'] ?? '') ?></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
        <a href="index.php?section=reviews" class="btn btn-back">← Назад</a>
    </form>
</div>
</body>
</html>

<?php
// ============================================
// НАСТРОЙКИ АДМИН-ПАНЕЛИ
// Измените логин и пароль перед размещением!
// ============================================

define('ADMIN_LOGIN', 'admin');
define('ADMIN_PASSWORD', 'fond2025!');

// Путь к папке с данными (относительно корня сайта)
define('DATA_DIR', __DIR__ . '/../data/');

// Путь к папке для загрузки изображений
define('UPLOAD_DIR', __DIR__ . '/../uploads/');

// Максимальный размер файла (5 МБ)
define('MAX_FILE_SIZE', 5 * 1024 * 1024);

// Допустимые типы файлов
define('ALLOWED_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

session_start();

function isLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function checkAuth() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function loadData($file) {
    $path = DATA_DIR . $file;
    if (!file_exists($path)) return [];
    $json = file_get_contents($path);
    return json_decode($json, true) ?: [];
}

function saveData($file, $data) {
    $path = DATA_DIR . $file;
    file_put_contents($path, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function getNextId($data) {
    $maxId = 0;
    foreach ($data as $item) {
        if (isset($item['id']) && $item['id'] > $maxId) $maxId = $item['id'];
    }
    return $maxId + 1;
}

function uploadImage($fileInput) {
    if (!isset($_FILES[$fileInput]) || $_FILES[$fileInput]['error'] !== UPLOAD_OK) {
        return '';
    }
    
    $file = $_FILES[$fileInput];
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return '';
    }
    
    if (!in_array($file['type'], ALLOWED_TYPES)) {
        return '';
    }
    
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
    
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'img_' . time() . '_' . mt_rand(1000, 9999) . '.' . $ext;
    $dest = UPLOAD_DIR . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $dest)) {
        return 'uploads/' . $filename;
    }
    
    return '';
}

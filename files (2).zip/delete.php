<?php
require_once 'config.php';
checkAuth();

$section = $_GET['section'] ?? '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$fileMap = [
    'news' => 'news.json',
    'awards' => 'awards.json',
    'reviews' => 'reviews.json'
];

if (isset($fileMap[$section]) && $id > 0) {
    $data = loadData($fileMap[$section]);
    $data = array_values(array_filter($data, function($item) use ($id) {
        return $item['id'] !== $id;
    }));
    saveData($fileMap[$section], $data);
}

header('Location: index.php?section=' . $section . '&msg=deleted');
exit;

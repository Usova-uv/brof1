<?php
require_once 'config.php';
checkAuth();

$awards = loadData('awards.json');
$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$item = null;

if ($editId) {
    foreach ($awards as $a) {
        if ($a['id'] === $editId) { $item = $a; break; }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $image = uploadImage('image');
    
    if ($editId && $item) {
        foreach ($awards as &$a) {
            if ($a['id'] === $editId) {
                $a['title'] = $title;
                if ($image) $a['image'] = $image;
                break;
            }
        }
    } else {
        $awards[] = [
            'id' => getNextId($awards),
            'title' => $title,
            'image' => $image ?: ''
        ];
    }
    
    saveData('awards.json', $awards);
    header('Location: index.php?section=awards&msg=saved');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $editId ? 'Редактировать' : 'Добавить' ?> грамоту</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f1f5f9; padding: 2rem; }
        .container { max-width: 700px; margin: 0 auto; }
        h1 { font-size: 1.6rem; color: #1B3A6B; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 6px; color: #374151; }
        .form-group input { width: 100%; padding: 12px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem; }
        .form-group input:focus { outline: none; border-color: #1B3A6B; }
        .form-group .help { font-size: 0.8rem; color: #94a3b8; margin-top: 4px; }
        .btn { display: inline-flex; padding: 14px 28px; border-radius: 10px; text-decoration: none; font-size: 1rem; font-weight: 700; border: none; cursor: pointer; }
        .btn-primary { background: #1B3A6B; color: white; }
        .btn-back { background: #e5e7eb; color: #374151; margin-left: 10px; }
        .current-img { max-width: 300px; border-radius: 8px; margin-top: 8px; }
    </style>
</head>
<body>
<div class="container">
    <h1><?= $editId ? '✏️ Редактировать грамоту' : '🏆 Добавить грамоту' ?></h1>
    
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Название *</label>
            <input type="text" name="title" value="<?= htmlspecialchars($item['title'] ?? '') ?>" required placeholder="Благодарственное письмо от...">
        </div>
        
        <div class="form-group">
            <label>Фото грамоты *</label>
            <input type="file" name="image" accept="image/*" <?= $editId ? '' : 'required' ?>>
            <div class="help">JPG, PNG или WebP. Максимум 5 МБ.</div>
            <?php if (!empty($item['image'])): ?>
                <img src="../<?= htmlspecialchars($item['image']) ?>" class="current-img" alt="">
            <?php endif; ?>
        </div>
        
        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
        <a href="index.php?section=awards" class="btn btn-back">← Назад</a>
    </form>
</div>
</body>
</html>

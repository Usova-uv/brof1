<?php
require_once 'config.php';
checkAuth();

$news = loadData('news.json');
$editId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$item = null;

if ($editId) {
    foreach ($news as $n) {
        if ($n['id'] === $editId) { $item = $n; break; }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $date = trim($_POST['date'] ?? date('Y-m-d'));
    $text = trim($_POST['text'] ?? '');
    $link = trim($_POST['link'] ?? '');
    $image = uploadImage('image');
    
    if ($editId && $item) {
        // Редактирование
        foreach ($news as &$n) {
            if ($n['id'] === $editId) {
                $n['title'] = $title;
                $n['date'] = $date;
                $n['text'] = $text;
                $n['link'] = $link;
                if ($image) $n['image'] = $image;
                break;
            }
        }
    } else {
        // Новая запись
        $news[] = [
            'id' => getNextId($news),
            'title' => $title,
            'date' => $date,
            'text' => $text,
            'image' => $image ?: 'images/news-default.jpg',
            'link' => $link
        ];
    }
    
    saveData('news.json', $news);
    header('Location: index.php?section=news&msg=saved');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $editId ? 'Редактировать' : 'Добавить' ?> новость</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f1f5f9; padding: 2rem; }
        .container { max-width: 700px; margin: 0 auto; }
        h1 { font-size: 1.6rem; color: #1B3A6B; margin-bottom: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 6px; color: #374151; }
        .form-group input, .form-group textarea { width: 100%; padding: 12px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem; font-family: inherit; }
        .form-group textarea { min-height: 120px; resize: vertical; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #1B3A6B; }
        .form-group .help { font-size: 0.8rem; color: #94a3b8; margin-top: 4px; }
        .btn { display: inline-flex; padding: 14px 28px; border-radius: 10px; text-decoration: none; font-size: 1rem; font-weight: 700; border: none; cursor: pointer; }
        .btn-primary { background: #1B3A6B; color: white; }
        .btn-back { background: #e5e7eb; color: #374151; margin-left: 10px; }
        .current-img { max-width: 200px; border-radius: 8px; margin-top: 8px; }
    </style>
</head>
<body>
<div class="container">
    <h1><?= $editId ? '✏️ Редактировать новость' : '📰 Добавить новость' ?></h1>
    
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Заголовок *</label>
            <input type="text" name="title" value="<?= htmlspecialchars($item['title'] ?? '') ?>" required>
        </div>
        
        <div class="form-group">
            <label>Дата</label>
            <input type="date" name="date" value="<?= htmlspecialchars($item['date'] ?? date('Y-m-d')) ?>">
        </div>
        
        <div class="form-group">
            <label>Текст новости *</label>
            <textarea name="text" required><?= htmlspecialchars($item['text'] ?? '') ?></textarea>
        </div>
        
        <div class="form-group">
            <label>Ссылка (URL)</label>
            <input type="url" name="link" value="<?= htmlspecialchars($item['link'] ?? '') ?>" placeholder="https://fond-omon.com/...">
        </div>
        
        <div class="form-group">
            <label>Фото</label>
            <input type="file" name="image" accept="image/*">
            <div class="help">JPG, PNG или WebP. Максимум 5 МБ.</div>
            <?php if (!empty($item['image'])): ?>
                <img src="../<?= htmlspecialchars($item['image']) ?>" class="current-img" alt="">
            <?php endif; ?>
        </div>
        
        <button type="submit" class="btn btn-primary">💾 Сохранить</button>
        <a href="index.php?section=news" class="btn btn-back">← Назад</a>
    </form>
</div>
</body>
</html>

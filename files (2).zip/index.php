<?php
require_once 'config.php';
checkAuth();

$news = loadData('news.json');
$awards = loadData('awards.json');
$reviews = loadData('reviews.json');

$section = $_GET['section'] ?? 'news';
$action = $_GET['action'] ?? 'list';
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель — БРОФ «Твардовского, 2»</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f1f5f9; color: #1e293b; }
        
        .sidebar { position: fixed; left: 0; top: 0; bottom: 0; width: 260px; background: #0f172a; color: white; padding: 2rem 0; }
        .sidebar .logo { text-align: center; font-size: 1.8rem; font-weight: 900; margin-bottom: 0.5rem; color: #60a5fa; }
        .sidebar .subtitle { text-align: center; font-size: 0.75rem; color: #94a3b8; margin-bottom: 2rem; }
        .sidebar nav a { display: flex; align-items: center; gap: 12px; padding: 14px 24px; color: #cbd5e1; text-decoration: none; font-size: 0.95rem; transition: all 0.2s; border-left: 3px solid transparent; }
        .sidebar nav a:hover, .sidebar nav a.active { background: #1e293b; color: white; border-left-color: #60a5fa; }
        .sidebar nav a .icon { font-size: 1.2rem; width: 24px; text-align: center; }
        .sidebar .logout { position: absolute; bottom: 2rem; left: 0; right: 0; padding: 0 24px; }
        .sidebar .logout a { display: block; text-align: center; padding: 10px; background: #dc2626; color: white; border-radius: 8px; text-decoration: none; font-weight: 600; }
        
        .main { margin-left: 260px; padding: 2rem 3rem; }
        .main h1 { font-size: 1.8rem; margin-bottom: 0.5rem; }
        .main .desc { color: #64748b; margin-bottom: 2rem; }
        
        .card { background: white; border-radius: 12px; padding: 1.5rem; margin-bottom: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
        .card-title { font-weight: 700; font-size: 1.1rem; }
        .card-date { color: #94a3b8; font-size: 0.85rem; }
        .card-text { color: #64748b; font-size: 0.9rem; line-height: 1.6; }
        .card-img { width: 80px; height: 60px; object-fit: cover; border-radius: 8px; }
        .card-actions { display: flex; gap: 8px; margin-top: 1rem; }
        
        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; text-decoration: none; font-size: 0.85rem; font-weight: 600; border: none; cursor: pointer; transition: all 0.2s; }
        .btn-primary { background: #1B3A6B; color: white; }
        .btn-primary:hover { background: #0f2a52; }
        .btn-danger { background: #fee2e2; color: #dc2626; }
        .btn-danger:hover { background: #fecaca; }
        .btn-success { background: #dcfce7; color: #16a34a; }
        .btn-add { background: #1B3A6B; color: white; padding: 12px 24px; font-size: 1rem; margin-bottom: 2rem; }
        .btn-add:hover { background: #0f2a52; }
        
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 6px; color: #374151; }
        .form-group input, .form-group textarea, .form-group select { width: 100%; padding: 12px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem; font-family: inherit; }
        .form-group textarea { min-height: 120px; resize: vertical; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #1B3A6B; }
        .form-group .help { font-size: 0.8rem; color: #94a3b8; margin-top: 4px; }
        
        .alert { padding: 14px 20px; border-radius: 10px; margin-bottom: 1.5rem; font-weight: 600; }
        .alert-success { background: #dcfce7; color: #16a34a; }
        .alert-error { background: #fee2e2; color: #dc2626; }
        
        .grid-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 1rem; }
        .grid-cards .card { text-align: center; }
        .grid-cards .card img { width: 100%; max-height: 200px; object-fit: contain; border-radius: 8px; margin-bottom: 0.5rem; }
        
        .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin-bottom: 2rem; }
        .stat-card { background: white; border-radius: 12px; padding: 1.5rem; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .stat-num { font-size: 2.5rem; font-weight: 900; color: #1B3A6B; }
        .stat-label { color: #64748b; font-size: 0.9rem; margin-top: 4px; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="logo">Т2</div>
    <div class="subtitle">Панель управления</div>
    <nav>
        <a href="?section=news" class="<?= $section === 'news' ? 'active' : '' ?>">
            <span class="icon">📰</span> Новости
        </a>
        <a href="?section=awards" class="<?= $section === 'awards' ? 'active' : '' ?>">
            <span class="icon">🏆</span> Грамоты
        </a>
        <a href="?section=reviews" class="<?= $section === 'reviews' ? 'active' : '' ?>">
            <span class="icon">💬</span> Отзывы
        </a>
    </nav>
    <div class="logout">
        <a href="logout.php">Выйти</a>
    </div>
</div>

<div class="main">

<?php if ($msg === 'saved'): ?>
    <div class="alert alert-success">✅ Сохранено успешно!</div>
<?php elseif ($msg === 'deleted'): ?>
    <div class="alert alert-success">🗑️ Запись удалена</div>
<?php endif; ?>

<?php if ($section === 'news'): ?>
    <!-- ===== НОВОСТИ ===== -->
    <h1>📰 Последние события</h1>
    <p class="desc">Управление новостями на главной странице сайта</p>
    
    <div class="stats">
        <div class="stat-card">
            <div class="stat-num"><?= count($news) ?></div>
            <div class="stat-label">Всего новостей</div>
        </div>
    </div>
    
    <a href="edit_news.php" class="btn btn-add">+ Добавить новость</a>
    
    <?php foreach (array_reverse($news) as $item): ?>
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title"><?= htmlspecialchars($item['title']) ?></div>
                <div class="card-date"><?= $item['date'] ?></div>
            </div>
            <?php if (!empty($item['image'])): ?>
                <img src="../<?= htmlspecialchars($item['image']) ?>" class="card-img" alt="">
            <?php endif; ?>
        </div>
        <div class="card-text"><?= htmlspecialchars($item['text']) ?></div>
        <div class="card-actions">
            <a href="edit_news.php?id=<?= $item['id'] ?>" class="btn btn-primary">✏️ Редактировать</a>
            <a href="delete.php?section=news&id=<?= $item['id'] ?>" class="btn btn-danger" onclick="return confirm('Удалить эту новость?')">🗑️ Удалить</a>
        </div>
    </div>
    <?php endforeach; ?>

<?php elseif ($section === 'awards'): ?>
    <!-- ===== ГРАМОТЫ ===== -->
    <h1>🏆 Грамоты и благодарности</h1>
    <p class="desc">Управление грамотами и благодарственными письмами</p>
    
    <a href="edit_award.php" class="btn btn-add">+ Добавить грамоту</a>
    
    <div class="grid-cards">
    <?php foreach ($awards as $item): ?>
        <div class="card">
            <?php if (!empty($item['image'])): ?>
                <img src="../<?= htmlspecialchars($item['image']) ?>" alt="">
            <?php endif; ?>
            <div class="card-title" style="font-size:0.9rem;"><?= htmlspecialchars($item['title']) ?></div>
            <div class="card-actions" style="justify-content:center;">
                <a href="edit_award.php?id=<?= $item['id'] ?>" class="btn btn-primary">✏️</a>
                <a href="delete.php?section=awards&id=<?= $item['id'] ?>" class="btn btn-danger" onclick="return confirm('Удалить?')">🗑️</a>
            </div>
        </div>
    <?php endforeach; ?>
    </div>

<?php elseif ($section === 'reviews'): ?>
    <!-- ===== ОТЗЫВЫ ===== -->
    <h1>💬 Отзывы</h1>
    <p class="desc">Управление отзывами на главной странице</p>
    
    <a href="edit_review.php" class="btn btn-add">+ Добавить отзыв</a>
    
    <?php foreach ($reviews as $item): ?>
    <div class="card">
        <div class="card-header">
            <div>
                <div class="card-title"><?= htmlspecialchars($item['name']) ?></div>
                <div class="card-date"><?= htmlspecialchars($item['role']) ?></div>
            </div>
        </div>
        <div class="card-text"><?= htmlspecialchars($item['text']) ?></div>
        <div class="card-actions">
            <a href="edit_review.php?id=<?= $item['id'] ?>" class="btn btn-primary">✏️ Редактировать</a>
            <a href="delete.php?section=reviews&id=<?= $item['id'] ?>" class="btn btn-danger" onclick="return confirm('Удалить этот отзыв?')">🗑️</a>
        </div>
    </div>
    <?php endforeach; ?>

<?php endif; ?>

</div>
</body>
</html>

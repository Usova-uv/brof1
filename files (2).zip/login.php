<?php
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if ($login === ADMIN_LOGIN && $password === ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход — Админ-панель БРОФ</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #0f172a; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .login-box { background: white; border-radius: 16px; padding: 3rem; width: 400px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .login-box h1 { font-size: 1.5rem; color: #1B3A6B; margin-bottom: 0.5rem; }
        .login-box p { color: #6b7280; margin-bottom: 2rem; font-size: 0.9rem; }
        label { display: block; font-weight: 600; margin-bottom: 6px; color: #374151; font-size: 0.9rem; }
        input[type="text"], input[type="password"] { width: 100%; padding: 12px 16px; border: 2px solid #e5e7eb; border-radius: 10px; font-size: 1rem; margin-bottom: 1.2rem; transition: border-color 0.2s; }
        input:focus { outline: none; border-color: #1B3A6B; }
        button { width: 100%; padding: 14px; background: #1B3A6B; color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 700; cursor: pointer; transition: background 0.2s; }
        button:hover { background: #0f2a52; }
        .error { background: #fef2f2; color: #dc2626; padding: 12px; border-radius: 10px; margin-bottom: 1.2rem; font-size: 0.9rem; text-align: center; }
        .logo { text-align: center; margin-bottom: 1.5rem; font-size: 2rem; font-weight: 900; color: #1B3A6B; }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="logo">Т2</div>
        <h1>Панель управления</h1>
        <p>БРОФ «Твардовского, 2»</p>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <label>Логин</label>
            <input type="text" name="login" required autofocus>
            <label>Пароль</label>
            <input type="password" name="password" required>
            <button type="submit">Войти</button>
        </form>
    </div>
</body>
</html>
